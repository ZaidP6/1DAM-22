package ejercicio;

import java.util.ArrayList;

public class MiMusica {

	ArrayList List = new ArrayList();
	
	
	
	
	
	public Cancion findByFree(){
		
		while (getClass(Cancion).Pago == false) {
			toString().concat(Cancion);
		}return Cancion;
	}
	
	
	
}

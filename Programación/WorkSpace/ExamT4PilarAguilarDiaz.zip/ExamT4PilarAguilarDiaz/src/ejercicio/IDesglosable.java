package ejercicio;

public interface IDesglosable {

	
	
}

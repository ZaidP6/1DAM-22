package ejercicio;

public class Exceptions {

}
